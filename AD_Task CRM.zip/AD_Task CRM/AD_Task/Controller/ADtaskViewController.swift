//
//  AddEventController.swift
//  MyCalendar
//
//  Created by DKS_mac on 2019/11/25.
//  Copyright © 2019 dks. All rights reserved.
//

// References:
// 1. https://dev.to/lawgimenez/implementing-the-expandable-cell-in-ios-uitableview-f7j
// 2. https://stackoverflow.com/questions/17018447/rounding-of-nsdate-to-nearest-hour-in-ios

// MARK: - TODOs

import UIKit
import CoreData
import Alamofire



class ADtaskViewController: UITableViewController {

    // MARK: - Outlets
    // MARK: - Constants
    // 每个section的行数
    let numberOfRows = [1,1,1,1]
    
  
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return numberOfRows[section]
    }

//    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//
//           let identifier = tableView.cellForRow(at: indexPath)?.reuseIdentifier
//           switch identifier {
//           case "locationCell": self.view.endEditing(true)
//           case "invitationCell": self.view.endEditing(true)
//
//           default:
//               print("Clicked cell not handled.")
//           }
//           tableView.deselectRow(at: indexPath, animated: true)
//           tableView.beginUpdates()
//           tableView.endUpdates()
//       }
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        // Get the new view controller using segue.destination.
//        // Pass the selected object to the new view controller.
//
//        // 添加地点
//        if segue.identifier == "add"{
//            let dest = (segue.destination) as! AddViewController
//
//
//        } else if segue.identifier == "ADTaskTableView"{
//            // 添加邀请对象
//            let dest = (segue.destination) as! ADTaskTableViewController
//
//        }
//    }
    
    
}
   
