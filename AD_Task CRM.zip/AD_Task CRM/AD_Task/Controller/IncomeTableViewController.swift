//
//  IncomeTableViewController.swift
//  AD_Task
//
//  Created by 李政航 on 2020/1/16.
//  Copyright © 2020 李政航. All rights reserved.
//

import UIKit
import Alamofire

struct ADTaskData: Decodable {
    var no: String
    var description: String
    var categoryItem: String
    var categorySystem: String
    var requestDate: String
    //var status: String
}

class IncomeTableViewController: UITableViewController {
    
    
    var no:String! = ""
    var categoryItem1:String! = ""
    var categorySystem1:String! = ""
    var descriptionField:String! = ""
    var headList = [ADHead_Properties]()
    func setTableViewData(headList:[ADHead_Properties]){
        self.headList = headList
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getADTask()
        //self.title="XYZ Main"
        let button = UIButton.init(type:.contactAdd)
        button.addTarget(self, action: #selector(IncomeTableViewController.doAdd)
            , for: .touchUpInside)
        // add button to TableView
        let buttonItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.rightBarButtonItem = buttonItem
        // self.navigationItem.rightBarButtonItem=self.editButtonItem
        
    }
    
    @objc func doAdd() {
        let ADtaskViewController = self.storyboard?.instantiateViewController(identifier: "add_Head")
        self.navigationController?.pushViewController(ADtaskViewController!, animated: true)
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return headList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! IncomeTableViewCell
        cell.noLabel.text = headList[indexPath.row].no
        cell.desLabel.text = headList[indexPath.row].descriptionField
        cell.itemLabel.text = headList[indexPath.row].categoryItem
        cell.sysLabel.text = headList[indexPath.row].categorySystem
        cell.rqDateLabel.text = String(headList[indexPath.row].requestDate ?? 0)
        return cell
    }
    
    // 設定cell的高度
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 195
    }
    
    
    //        override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    //
    //            if let next = storyboard?.instantiateViewController(withIdentifier: "add_Head") as?
    //                IncomeTableViewCell{
    //                if indexPath.row == 0{
    //                    next.no1 = headList[indexPath.row].no
    //                    next.des1 = headList[indexPath.row].descriptionField
    //                    next.item = headList[indexPath.row].categoryItem
    //                    next.sys = headList[indexPath.row].categorySystem
    //                    next.rqDate = String(headList[indexPath.row].requestDate ?? 0)
    //                    self.navigationController?.pushViewController(next, animated: true)
    //                }else{
    //                    next.no1 = headList[indexPath.row].no
    //                    next.des1 = headList[indexPath.row].descriptionField
    //                    next.item = headList[indexPath.row].categoryItem
    //                    next.sys = headList[indexPath.row].categorySystem
    //                     next.rqDate = String(headList[indexPath.row].requestDate ?? 0)
    //                                   self.navigationController?.pushViewController(next, animated: true)
    //                }
    //            }
    //
    //        }
    
    
    @objc func getADTask() {

        let urlStr = "http://60.250.137.187:18080/erppos_off_restAPI/rest/TaskService/TasksBean"
        Alamofire.request(urlStr).responseJSON { (response) in
            switch response.result {
            case .success(let json):
                
                print(json)
                if let headList = try? JSONDecoder().decode([ADHead_Properties].self, from: response.data!){
                    print(headList)
                    
                    for headList in headList {
                        // self.setTableViewData(apiList: [apiList])
                        self.headList.append(headList)
                        // self.status1.append(adk.status)
        
                    }
                    DispatchQueue.main.async{
                        self.tableView.reloadData()
                        self.refreshControl?.endRefreshing()
                        
                    }
                    
                    // self.navigationController?.pushViewController(next, animated: true)
                }
                break
            case .failure(let error):
                print("error:\(error)")
                // self.navigationController?.pushViewController(next, animated: true)
                break
            }
        }
        
    }
    
    
}
