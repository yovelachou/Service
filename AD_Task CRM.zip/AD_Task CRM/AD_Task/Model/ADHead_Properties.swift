//
//  aipDAO.swift
//  AD_Task
//
//  Created by 李政航 on 2019/11/29.
//  Copyright © 2019 李政航. All rights reserved.
//

import Foundation
struct ADHead_Properties : Codable {

    let applicant : String?
    let assignmentId : Int?
    let brandCode : String?
    let categoryCode : String?
    let categoryGroup : String?
    let categoryItem : String?
    let categorySystem : String?
    let classification : String?
    let contractTel : String?
    let costControl : String?
    let createdBy : String?
    let createdByName : String?
    let creationDate : Int?
    let depManager : String?
    let depManagerName : String?
    let depName : String?
    let department : String?
    let descriptionField : String?
    let enFristName : String?
    let enName : String?
    let estimateEndDare : String?
    let estimateStartDare : String?
    let headId : Int?
    let hisstoryInfo : String?
    let lastUpdateDate : Int?
    let lastUpdatedBy : String?
    let lastUpdatedByName : String?
    let no : String?
    let orderNo : String?
    let orderTypeCode : String?
    let otherGroup : String?
    let priority : String?
    let processDescription : String?
    let processId : Int?
    let project : String?
    let projectId : String?
    let request : String?
    let requestCode : String?
    let requestDate : Int?
    let requestSource : String?
    let role : String?
    let rqInChargeCode : String?
    let special : String?
    let status : String?
    let statusLog : String?
    let totalHours : String?
    let warehouseControl : String?


    enum CodingKeys: String, CodingKey {
        case applicant = "applicant"
        case assignmentId = "assignmentId"
        case brandCode = "brandCode"
        case categoryCode = "categoryCode"
        case categoryGroup = "categoryGroup"
        case categoryItem = "categoryItem"
        case categorySystem = "categorySystem"
        case classification = "classification"
        case contractTel = "contractTel"
        case costControl = "costControl"
        case createdBy = "createdBy"
        case createdByName = "createdByName"
        case creationDate = "creationDate"
        case depManager = "depManager"
        case depManagerName = "depManagerName"
        case depName = "depName"
        case department = "department"
        case descriptionField = "description"
        case enFristName = "enFristName"
        case enName = "enName"
        case estimateEndDare = "estimateEndDare"
        case estimateStartDare = "estimateStartDare"
        case headId = "headId"
        case hisstoryInfo = "hisstoryInfo"
        case lastUpdateDate = "lastUpdateDate"
        case lastUpdatedBy = "lastUpdatedBy"
        case lastUpdatedByName = "lastUpdatedByName"
        case no = "no"
        case orderNo = "orderNo"
        case orderTypeCode = "orderTypeCode"
        case otherGroup = "otherGroup"
        case priority = "priority"
        case processDescription = "processDescription"
        case processId = "processId"
        case project = "project"
        case projectId = "projectId"
        case request = "request"
        case requestCode = "requestCode"
        case requestDate = "requestDate"
        case requestSource = "requestSource"
        case role = "role"
        case rqInChargeCode = "rqInChargeCode"
        case special = "special"
        case status = "status"
        case statusLog = "statusLog"
        case totalHours = "totalHours"
        case warehouseControl = "warehouseControl"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        applicant = try values.decodeIfPresent(String.self, forKey: .applicant)
        assignmentId = try values.decodeIfPresent(Int.self, forKey: .assignmentId)
        brandCode = try values.decodeIfPresent(String.self, forKey: .brandCode)
        categoryCode = try values.decodeIfPresent(String.self, forKey: .categoryCode)
        categoryGroup = try values.decodeIfPresent(String.self, forKey: .categoryGroup)
        categoryItem = try values.decodeIfPresent(String.self, forKey: .categoryItem)
        categorySystem = try values.decodeIfPresent(String.self, forKey: .categorySystem)
        classification = try values.decodeIfPresent(String.self, forKey: .classification)
        contractTel = try values.decodeIfPresent(String.self, forKey: .contractTel)
        costControl = try values.decodeIfPresent(String.self, forKey: .costControl)
        createdBy = try values.decodeIfPresent(String.self, forKey: .createdBy)
        createdByName = try values.decodeIfPresent(String.self, forKey: .createdByName)
        creationDate = try values.decodeIfPresent(Int.self, forKey: .creationDate)
        depManager = try values.decodeIfPresent(String.self, forKey: .depManager)
        depManagerName = try values.decodeIfPresent(String.self, forKey: .depManagerName)
        depName = try values.decodeIfPresent(String.self, forKey: .depName)
        department = try values.decodeIfPresent(String.self, forKey: .department)
        descriptionField = try values.decodeIfPresent(String.self, forKey: .descriptionField)
        enFristName = try values.decodeIfPresent(String.self, forKey: .enFristName)
        enName = try values.decodeIfPresent(String.self, forKey: .enName)
        estimateEndDare = try values.decodeIfPresent(String.self, forKey: .estimateEndDare)
        estimateStartDare = try values.decodeIfPresent(String.self, forKey: .estimateStartDare)
        headId = try values.decodeIfPresent(Int.self, forKey: .headId)
        hisstoryInfo = try values.decodeIfPresent(String.self, forKey: .hisstoryInfo)
        lastUpdateDate = try values.decodeIfPresent(Int.self, forKey: .lastUpdateDate)
        lastUpdatedBy = try values.decodeIfPresent(String.self, forKey: .lastUpdatedBy)
        lastUpdatedByName = try values.decodeIfPresent(String.self, forKey: .lastUpdatedByName)
        no = try values.decodeIfPresent(String.self, forKey: .no)
        orderNo = try values.decodeIfPresent(String.self, forKey: .orderNo)
        orderTypeCode = try values.decodeIfPresent(String.self, forKey: .orderTypeCode)
        otherGroup = try values.decodeIfPresent(String.self, forKey: .otherGroup)
        priority = try values.decodeIfPresent(String.self, forKey: .priority)
        processDescription = try values.decodeIfPresent(String.self, forKey: .processDescription)
        processId = try values.decodeIfPresent(Int.self, forKey: .processId)
        project = try values.decodeIfPresent(String.self, forKey: .project)
        projectId = try values.decodeIfPresent(String.self, forKey: .projectId)
        request = try values.decodeIfPresent(String.self, forKey: .request)
        requestCode = try values.decodeIfPresent(String.self, forKey: .requestCode)
        requestDate = try values.decodeIfPresent(Int.self, forKey: .requestDate)
        requestSource = try values.decodeIfPresent(String.self, forKey: .requestSource)
        role = try values.decodeIfPresent(String.self, forKey: .role)
        rqInChargeCode = try values.decodeIfPresent(String.self, forKey: .rqInChargeCode)
        special = try values.decodeIfPresent(String.self, forKey: .special)
        status = try values.decodeIfPresent(String.self, forKey: .status)
        statusLog = try values.decodeIfPresent(String.self, forKey: .statusLog)
        totalHours = try values.decodeIfPresent(String.self, forKey: .totalHours)
        warehouseControl = try values.decodeIfPresent(String.self, forKey: .warehouseControl)
    }
}
