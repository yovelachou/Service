
//
//    RootClass.swift
//    Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation

struct login_Properties : Codable {

    let adHours : Int?
    let adPreHours : Int?
    let address1 : String?
    let address2 : String?
    let address3 : String?
    let address4 : String?
    let addressBookId : Int?
    let appointmentDate : Int?
    let area1 : String?
    let area2 : String?
    let area3 : String?
    let area4 : String?
    let arriveDate : Int?
    let brandCode : String?
    let buEmployeeBrands : [String]?
    let city1 : String?
    let city2 : String?
    let city3 : String?
    let city4 : String?
    let costControl : String?
    let costDepartment : String?
    let createdBy : String?
    let creationDate : Int?
    let dayOff : String?
    let email1 : String?
    let email2 : String?
    let email3 : String?
    let email4 : String?
    let emailCompany : String?
    let employeeCode : String?
    let employeeDepartment : String?
    let employeeGroup : String?
    let employeeName : String?
    let employeePosition : String?
    let employeeRole : String?
    let employeeType : String?
    let employeeZone : String?
    //let extension : String?
    let fax1 : String?
    let fax2 : String?
    let fax3 : String?
    let fax4 : String?
    let isDepartmentManager : String?
    let keyInMode : String?
    let lastUpdateDate : Int?
    let lastUpdatedBy : String?
    let leaveDate : String?
    let leaveWithoutPayDate : String?
    let loginName : String?
    let password : String?
    let projectHours : Int?
    let reinstatementDate : String?
    let remark1 : String?
    let remark2 : String?
    let remark3 : String?
    let reportLoginName : String?
    let reportPassword : String?
    let seniorityDate : Int?
    let switchTo : String?
    let tel1 : String?
    let tel2 : String?
    let tel3 : String?
    let tel4 : String?
    let warehouseControl : String?
    let workType : String?
    let zipCode1 : String?
    let zipCode2 : String?
    let zipCode3 : String?
    let zipCode4 : String?


    enum CodingKeys: String, CodingKey {
        case adHours = "adHours"
        case adPreHours = "adPreHours"
        case address1 = "address1"
        case address2 = "address2"
        case address3 = "address3"
        case address4 = "address4"
        case addressBookId = "addressBookId"
        case appointmentDate = "appointmentDate"
        case area1 = "area1"
        case area2 = "area2"
        case area3 = "area3"
        case area4 = "area4"
        case arriveDate = "arriveDate"
        case brandCode = "brandCode"
        case buEmployeeBrands = "buEmployeeBrands"
        case city1 = "city1"
        case city2 = "city2"
        case city3 = "city3"
        case city4 = "city4"
        case costControl = "costControl"
        case costDepartment = "costDepartment"
        case createdBy = "createdBy"
        case creationDate = "creationDate"
        case dayOff = "dayOff"
        case email1 = "email1"
        case email2 = "email2"
        case email3 = "email3"
        case email4 = "email4"
        case emailCompany = "emailCompany"
        case employeeCode = "employeeCode"
        case employeeDepartment = "employeeDepartment"
        case employeeGroup = "employeeGroup"
        case employeeName = "employeeName"
        case employeePosition = "employeePosition"
        case employeeRole = "employeeRole"
        case employeeType = "employeeType"
        case employeeZone = "employeeZone"
        //case extension = "extension"
        case fax1 = "fax1"
        case fax2 = "fax2"
        case fax3 = "fax3"
        case fax4 = "fax4"
        case isDepartmentManager = "isDepartmentManager"
        case keyInMode = "keyInMode"
        case lastUpdateDate = "lastUpdateDate"
        case lastUpdatedBy = "lastUpdatedBy"
        case leaveDate = "leaveDate"
        case leaveWithoutPayDate = "leaveWithoutPayDate"
        case loginName = "loginName"
        case password = "password"
        case projectHours = "projectHours"
        case reinstatementDate = "reinstatementDate"
        case remark1 = "remark1"
        case remark2 = "remark2"
        case remark3 = "remark3"
        case reportLoginName = "reportLoginName"
        case reportPassword = "reportPassword"
        case seniorityDate = "seniorityDate"
        case switchTo = "switchTo"
        case tel1 = "tel1"
        case tel2 = "tel2"
        case tel3 = "tel3"
        case tel4 = "tel4"
        case warehouseControl = "warehouseControl"
        case workType = "workType"
        case zipCode1 = "zipCode1"
        case zipCode2 = "zipCode2"
        case zipCode3 = "zipCode3"
        case zipCode4 = "zipCode4"
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        adHours = try values.decodeIfPresent(Int.self, forKey: .adHours)
        adPreHours = try values.decodeIfPresent(Int.self, forKey: .adPreHours)
        address1 = try values.decodeIfPresent(String.self, forKey: .address1)
        address2 = try values.decodeIfPresent(String.self, forKey: .address2)
        address3 = try values.decodeIfPresent(String.self, forKey: .address3)
        address4 = try values.decodeIfPresent(String.self, forKey: .address4)
        addressBookId = try values.decodeIfPresent(Int.self, forKey: .addressBookId)
        appointmentDate = try values.decodeIfPresent(Int.self, forKey: .appointmentDate)
        area1 = try values.decodeIfPresent(String.self, forKey: .area1)
        area2 = try values.decodeIfPresent(String.self, forKey: .area2)
        area3 = try values.decodeIfPresent(String.self, forKey: .area3)
        area4 = try values.decodeIfPresent(String.self, forKey: .area4)
        arriveDate = try values.decodeIfPresent(Int.self, forKey: .arriveDate)
        brandCode = try values.decodeIfPresent(String.self, forKey: .brandCode)
        buEmployeeBrands = try values.decodeIfPresent([String].self, forKey: .buEmployeeBrands)
        city1 = try values.decodeIfPresent(String.self, forKey: .city1)
        city2 = try values.decodeIfPresent(String.self, forKey: .city2)
        city3 = try values.decodeIfPresent(String.self, forKey: .city3)
        city4 = try values.decodeIfPresent(String.self, forKey: .city4)
        costControl = try values.decodeIfPresent(String.self, forKey: .costControl)
        costDepartment = try values.decodeIfPresent(String.self, forKey: .costDepartment)
        createdBy = try values.decodeIfPresent(String.self, forKey: .createdBy)
        creationDate = try values.decodeIfPresent(Int.self, forKey: .creationDate)
        dayOff = try values.decodeIfPresent(String.self, forKey: .dayOff)
        email1 = try values.decodeIfPresent(String.self, forKey: .email1)
        email2 = try values.decodeIfPresent(String.self, forKey: .email2)
        email3 = try values.decodeIfPresent(String.self, forKey: .email3)
        email4 = try values.decodeIfPresent(String.self, forKey: .email4)
        emailCompany = try values.decodeIfPresent(String.self, forKey: .emailCompany)
        employeeCode = try values.decodeIfPresent(String.self, forKey: .employeeCode)
        employeeDepartment = try values.decodeIfPresent(String.self, forKey: .employeeDepartment)
        employeeGroup = try values.decodeIfPresent(String.self, forKey: .employeeGroup)
        employeeName = try values.decodeIfPresent(String.self, forKey: .employeeName)
        employeePosition = try values.decodeIfPresent(String.self, forKey: .employeePosition)
        employeeRole = try values.decodeIfPresent(String.self, forKey: .employeeRole)
        employeeType = try values.decodeIfPresent(String.self, forKey: .employeeType)
        employeeZone = try values.decodeIfPresent(String.self, forKey: .employeeZone)
//        extension = try values.decodeIfPresent(String.self, forKey: .extension)
        fax1 = try values.decodeIfPresent(String.self, forKey: .fax1)
        fax2 = try values.decodeIfPresent(String.self, forKey: .fax2)
        fax3 = try values.decodeIfPresent(String.self, forKey: .fax3)
        fax4 = try values.decodeIfPresent(String.self, forKey: .fax4)
        isDepartmentManager = try values.decodeIfPresent(String.self, forKey: .isDepartmentManager)
        keyInMode = try values.decodeIfPresent(String.self, forKey: .keyInMode)
        lastUpdateDate = try values.decodeIfPresent(Int.self, forKey: .lastUpdateDate)
        lastUpdatedBy = try values.decodeIfPresent(String.self, forKey: .lastUpdatedBy)
        leaveDate = try values.decodeIfPresent(String.self, forKey: .leaveDate)
        leaveWithoutPayDate = try values.decodeIfPresent(String.self, forKey: .leaveWithoutPayDate)
        loginName = try values.decodeIfPresent(String.self, forKey: .loginName)
        password = try values.decodeIfPresent(String.self, forKey: .password)
        projectHours = try values.decodeIfPresent(Int.self, forKey: .projectHours)
        reinstatementDate = try values.decodeIfPresent(String.self, forKey: .reinstatementDate)
        remark1 = try values.decodeIfPresent(String.self, forKey: .remark1)
        remark2 = try values.decodeIfPresent(String.self, forKey: .remark2)
        remark3 = try values.decodeIfPresent(String.self, forKey: .remark3)
        reportLoginName = try values.decodeIfPresent(String.self, forKey: .reportLoginName)
        reportPassword = try values.decodeIfPresent(String.self, forKey: .reportPassword)
        seniorityDate = try values.decodeIfPresent(Int.self, forKey: .seniorityDate)
        switchTo = try values.decodeIfPresent(String.self, forKey: .switchTo)
        tel1 = try values.decodeIfPresent(String.self, forKey: .tel1)
        tel2 = try values.decodeIfPresent(String.self, forKey: .tel2)
        tel3 = try values.decodeIfPresent(String.self, forKey: .tel3)
        tel4 = try values.decodeIfPresent(String.self, forKey: .tel4)
        warehouseControl = try values.decodeIfPresent(String.self, forKey: .warehouseControl)
        workType = try values.decodeIfPresent(String.self, forKey: .workType)
        zipCode1 = try values.decodeIfPresent(String.self, forKey: .zipCode1)
        zipCode2 = try values.decodeIfPresent(String.self, forKey: .zipCode2)
        zipCode3 = try values.decodeIfPresent(String.self, forKey: .zipCode3)
        zipCode4 = try values.decodeIfPresent(String.self, forKey: .zipCode4)
    }


}
