//
//  IncomeTableViewCell.swift
//  AD_Task
//
//  Created by 李政航 on 2020/1/16.
//  Copyright © 2020 李政航. All rights reserved.
//

import UIKit

class IncomeTableViewCell: UITableViewCell {

    @IBOutlet weak var noLabel: UILabel!
    @IBOutlet weak var desLabel: UILabel!
    @IBOutlet weak var itemLabel: UILabel!
    @IBOutlet weak var sysLabel: UILabel!
    @IBOutlet weak var rqDateLabel: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
